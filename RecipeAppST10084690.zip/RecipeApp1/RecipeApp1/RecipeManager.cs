﻿namespace RecipeApp1
{
    public class RecipeManager
    {
        private List<Recipe> recipes;

        public RecipeManager()
        {
            recipes = new List<Recipe>();
        }

        public void AddRecipe(Recipe recipe)
        {
            recipes.Add(recipe);
        }

        public void DisplayRecipeList()
        {
            recipes.Sort((x, y) => string.Compare(x.Name, y.Name));
            Console.WriteLine("Recipe List:");
            foreach (var recipe in recipes)
            {
                Console.WriteLine(recipe.Name);
            }
        }

        public Recipe GetRecipeByName(string name)
        {
            return recipes.Find(r => r.Name == name);
        }
    }

}
