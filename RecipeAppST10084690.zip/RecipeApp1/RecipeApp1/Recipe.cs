﻿namespace RecipeApp1
{
    public class Recipe
    {
        public string Name { get; set; }
        private List<Ingredient> ingredients;
        private List<string> steps;
        private double totalCalories;

        public Recipe(string name)
        {
            Name = name;
            ingredients = new List<Ingredient>();
            steps = new List<string>();
            totalCalories = 0;
        }

        public void AddIngredient(Ingredient ingredient)
        {
            ingredients.Add(ingredient);
            totalCalories += ingredient.Calories;
        }

        public void AddStep(string step)
        {
            steps.Add(step);
        }

        public void DisplayRecipe()
        {
            Console.WriteLine($"Recipe: {Name}");
            Console.WriteLine("Ingredients:");
            foreach (var ingredient in ingredients)
            {
                Console.WriteLine(ingredient);
            }

            Console.WriteLine("\nSteps:");
            for (int i = 0; i < steps.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {steps[i]}");
            }
            Console.WriteLine($"Total Calories: {totalCalories}");
        }

        public bool ExceedsCalorieLimit()
        {
            return totalCalories > 300;
        }
    }

}
