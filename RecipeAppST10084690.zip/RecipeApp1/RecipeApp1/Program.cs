using RecipeApp1;
using System;

class Program
{
    static RecipeManager recipeManager = new RecipeManager();

    static void Main(string[] args)
    {
        bool running = true;

        while (running)
        {
            Console.WriteLine("\nRecipe Application");
            Console.WriteLine("1. Enter a new recipe");
            Console.WriteLine("2. Display all recipes");
            Console.WriteLine("3. Select and display a recipe");
            Console.WriteLine("4. Exit");

            Console.Write("Select an option: ");
            string option = Console.ReadLine();

            switch (option)
            {
                case "1":
                    EnterNewRecipe();
                    break;
                case "2":
                    DisplayAllRecipes();
                    break;
                case "3":
                    SelectAndDisplayRecipe();
                    break;
                case "4":
                    running = false;
                    break;
                default:
                    Console.WriteLine("Invalid option, please try again.");
                    break;
            }
        }
    }

    static void EnterNewRecipe()
    {
        Console.Write("Enter recipe name: ");
        string name = Console.ReadLine();

        Recipe recipe = new Recipe(name);

        Console.Write("Enter the number of ingredients: ");
        int numIngredients = int.Parse(Console.ReadLine());

        for (int i = 0; i < numIngredients; i++)
        {
            Console.Write("Enter the name of ingredient: ");
            string ingredientName = Console.ReadLine();
            Console.Write("Enter the quantity of ingredient: ");
            double quantity = double.Parse(Console.ReadLine());
            Console.Write("Enter the unit of measurement: ");
            string unit = Console.ReadLine();
            Console.Write("Enter the number of calories: ");
            double calories = double.Parse(Console.ReadLine());
            Console.Write("Enter the food group: ");
            string foodGroup = Console.ReadLine();

            Ingredient ingredient = new Ingredient(ingredientName, quantity, unit, calories, foodGroup);
            recipe.AddIngredient(ingredient);
        }

        Console.Write("Enter the number of steps: ");
        int numSteps = int.Parse(Console.ReadLine());

        for (int i = 0; i < numSteps; i++)
        {
            Console.Write($"Enter step {i + 1}: ");
            string step = Console.ReadLine();
            recipe.AddStep(step);
        }

        recipeManager.AddRecipe(recipe);
    }

    static void DisplayAllRecipes()
    {
        recipeManager.DisplayRecipeList();
    }

    static void SelectAndDisplayRecipe()
    {
        Console.Write("Enter recipe name: ");
        string name = Console.ReadLine();
        Recipe recipe = recipeManager.GetRecipeByName(name);

        if (recipe != null)
        {
            recipe.DisplayRecipe();
            if (recipe.ExceedsCalorieLimit())
            {
                Console.WriteLine("Warning: This recipe exceeds 300 calories.");
            }
        }
        else
        {
            Console.WriteLine("Recipe not found.");
        }
    }
}
